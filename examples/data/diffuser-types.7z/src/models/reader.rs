use sevenz_rust::{Error, Password, SevenZArchiveEntry, SevenZReader};
use std::io::Read;

#[test]
fn test() {
    let mut reader = SevenZReader::open("waifu-diffuser-types.7z", Password::empty()).unwrap();
    let file = "";
    let mut buffer = Vec::new();
    reader
        .for_each_entries(|entry, read| {
            if entry.is_directory {
                return Ok(true);
            }
            println!("{:?}", entry);
            if !entry.name.eq_ignore_ascii_case(file) {
                return Ok(true);
            }
            match read.read_to_end(&mut buffer) {
                Ok(_) => Ok(false),
                Err(e) => Err(Error::io(e)),
            }
        })
        .unwrap();
}
