## Tests

```bash
wee test
```
